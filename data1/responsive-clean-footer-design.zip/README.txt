A Pen created at CodePen.io. You can find this one at https://codepen.io/mofny/pen/RWBeLJ.

 A recreation & redevelop of the footer at Pavilion.  I used some flex display trickery to stick it at the bottom and for the responsiveness.  Overall, I love the colors, and the responsive logic is incredibly simple.  Also, I'm in love with flex.  I'll never go back to floats or tables again!